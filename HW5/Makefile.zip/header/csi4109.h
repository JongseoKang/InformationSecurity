#ifndef _CSI4109_h_
#define _CSI4109_H_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int add_section(char *infilepath, unsigned char *buf, size_t buf_len);

#endif